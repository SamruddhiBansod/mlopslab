import os
from google.cloud import storage
import csv
from io import StringIO

def process_file(event, context):
    """Triggered by a change to a Cloud Storage bucket.
    Reads a CSV file, computes simple stats, and writes a summary file.
    """

    bucket_name = event['bucket']
    file_name = event['name']

    # Only process CSV files
    if not file_name.lower().endswith(".csv"):
        print(f"Skipping non-CSV file: {file_name}")
        return

    print(f"Processing file: {file_name} from bucket: {bucket_name}")

    storage_client = storage.Client()

    # Download the CSV content
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(file_name)
    csv_data = blob.download_as_text()

    f = StringIO(csv_data)
    reader = csv.DictReader(f)

    row_count = 0
    column_names = reader.fieldnames or []
    age_sum = 0.0
    age_count = 0

    for row in reader:
        row_count += 1
        # If dataset has 'age' column, compute average age
        if "age" in row and row["age"]:
            try:
                age_value = float(row["age"])
                age_sum += age_value
                age_count += 1
            except ValueError:
                # Ignore invalid numeric values
                pass

    avg_age = age_sum / age_count if age_count > 0 else None

    summary_lines = [
        f"File processed: {file_name}",
        f"Total rows (excluding header): {row_count}",
        f"Columns: {', '.join(column_names) if column_names else 'None'}",
    ]

    if avg_age is not None:
        summary_lines.append(f"Average age (based on {age_count} rows): {avg_age:.2f}")
    else:
        summary_lines.append("Average age: not available (no valid 'age' column)")

    summary_text = "\n".join(summary_lines)

    # Write summary to processed bucket
    processed_bucket_name = os.environ.get("PROCESSED_BUCKET")
    if not processed_bucket_name:
        print("No PROCESSED_BUCKET environment variable set.")
        return

    processed_bucket = storage_client.bucket(processed_bucket_name)
    summary_filename = f"{file_name}.summary.txt"
    summary_blob = processed_bucket.blob(summary_filename)
    summary_blob.upload_from_string(summary_text)

    print(f"Summary written to {processed_bucket_name}/{summary_filename}")
